﻿WARNING : THIS IS A TEMPORARY DISK. 

Any data stored on this drive is SUBJECT TO LOSS and THERE IS NO WAY TO RECOVER IT.

Please do not use this disk for storing any personal or application data.

For additional details please refer to the MSDN documentation at : http://msdn.microsoft.com/en-us/library/windowsazure/jj672979.aspx


警告：此为临时磁盘。

存储在此驱动器上的任何数据都可能丢失，也无法恢复。

请不要使用该磁盘存储任何个人或应用程序数据。

有关更多详细信息，请参阅以下MSDN文档：http://msdn.microsoft.com/zh-cn/library/windowsazure/jj672979.aspx